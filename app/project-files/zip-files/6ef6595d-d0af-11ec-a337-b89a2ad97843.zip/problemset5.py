

# Input: A binomial coeffecient, read "m choose n".
# Output: The computation of the binomial coeffecient.
def binomial_coeffecient(m, n):
      A = [0 for i in range(m)]
      
      ## Row 0 of Pascal's triangle = 1. So, nC0 = 1.
      A[0] = 1 

      ## Compute the rows of Pascal's triangle starting at row 1. 
      ## Uses the previous row.
      for i in range(1, m + 1):
            j = min(i, n)
            while (j > 0):
                  A[j] = A[j] + A[j - 1]
                  j -= 1
      return A[n]

class Node:
      prev, next = None, None
      data = None

      def __init__(self, data):
            self.data = data
      
      def set_previous(self, previous_node):
            self.prev = previous_node
      
      def set_next(self, next_node):
            self.next = next_node
      
      def get_next_node(self):
            return self.next

      def get_prev_node(self):
            return self.prev
      
      def get_data(self):
            return self.data

class LinkedList:
      tail = None
      head = None
      len = 0

      def __init__(self):
            len = 0

      def add(self, data):
            if (self.head == None):
                  self.head = Node(data)
                  self.tail = self.head
                  self.len = self.len + 1
            elif (self.head.get_next_node == None):
                  new_node = Node(data)
                  self.head.set_next(new_node)
                  self.tail = new_node
                  self.len = self.len + 1
            else:
                  add(self,data)

      def get_length(self):
            return len

      def __iter__(self):
            return iter(self)

linked_list = LinkedList()
linked_list.add(5)
linked_list.add(12)
linked_list.add(52)
linked_list.add(36)
linked_list.add(56)

for i in linked_list:
      print(i)

'''
def match(card1, card2):
      return True if (card1 == card2) else False

memo = [1, 2, 1, 3, 4, 5, 2, 7, 8, 9]
def trick(sequence, card):
      global memo
      if (card in memo):
            return memo[card]
      elif (card == len(sequence)):
            return 1
      else:
            f = match()'''