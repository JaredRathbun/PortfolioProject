# Cable Manager

The goal of this project is to allow users to manage a database of computer cables, being able to store their locations along with their colors and types of connectors along with more information.

---
<br>

## Getting Started and Running the Project

This project runs off of Java Spring Boot, which is a framework that allows for easy database access along with easy frontend development.

1. First, unzip the .zip file into a directory of your choosing.
2. In NetBeans, Click File > New Project > Java with Maven (under categories section)> Project with Existing POM (under projects section) > Finish.
    - NOTE: A dialog will appear to select the project, you should see a maven project for the unzipped folder.
3. Once loaded, Maven may do some indexing. Once completed, **right click on the entry point (CableManagerApplication.java) and click "Run File".**
4. The application should start and display the URL it is running on.
5. Last, navigate to the URL that the program displays in a web browser. By default it should be [http://localhost:8080](http://localhost:8080). You should see the starting page for the application.

## Command Line Arguments
- Upon starting the application, if the command line flag **--sampledata** is passed, a stored procedure is run that insert test data into the database. While this is specifically for testing purposes, it inserts data that is useful for testing functionality.

## Using the UI
- In the center of the page, there is a table of cables which can be clicked. When each row of the table is clicked, the right side of the page populates with information related to that specific cable. Specifically, connectors and colors are shown with red "X's" to delete the respective piece of data. There are also delete buttons next to each cable in the main table, which deletes that given cable.
