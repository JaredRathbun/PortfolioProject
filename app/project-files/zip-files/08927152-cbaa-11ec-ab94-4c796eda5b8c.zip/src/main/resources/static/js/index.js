async function populateTables(row) {
    // Clear the right-div of any contents.
    const rightDiv = document.getElementById('right-div');
    rightDiv.innerHTML = '';

    await fetch(`/getconnectors/${row.id}`)
        .then((res) => res = res.json())
        .then((data) => fillConnectorData(data));

    await fetch(`/getcolors/${row.id}`)
        .then((res) => res = res.json())
        .then((data) => fillColorData(data));

    function fillConnectorData(data) {
        if (data.length > 0) {
            const header = document.createElement('h5');
            header.appendChild(document.createTextNode('Connectors'));
            header.style.margin = '10px';
            rightDiv.appendChild(header);

            const table = document.createElement('table');
            table.id = 'connector-table';
            const head = document.createElement('tr');
            const th1 = document.createElement('th');
            const th2 = document.createElement('th'); 
            th2.appendChild(document.createTextNode('Connector Name'));
            head.appendChild(th1);
            head.appendChild(th2);

            table.appendChild(head);

            table.setAttribute('class', 'table-hover');
            table.setAttribute('class', 'table-striped');
            table.setAttribute('class', 'table-condensed');
            table.setAttribute('class', 'table-responsive');
            for (connector of data) {
                var tr = document.createElement('tr'); 

                var deleteTd = document.createElement('td');
                var deleteButton = document.createElement('button');
                deleteButton.setAttribute('class', 'btn-close');
                deleteButton.setAttribute('type', 'button');
                deleteButton.onclick = () => {removeConnector(row.id, connector.id);}
                var span = document.createElement('span');
                span.setAttribute('class', 'icon-cross');
                deleteButton.appendChild(span);
                deleteTd.appendChild(deleteButton);

                var td2 = document.createElement('td');  
                td2.appendChild(document.createTextNode(connector.connectorName));
                tr.appendChild(deleteTd);
                tr.appendChild(td2);
                
                tr.id = connector.id;
                table.appendChild(tr);
            }
            rightDiv.appendChild(table);
        } else {
            const div = document.createElement('div');
            div.style.textAlign = "center";
            div.style.margin = "10px";
            div.style.marginTop = "50px";
            const header = document.createElement('h5');
            header.appendChild(document.createTextNode("No Connectors :("));
            div.appendChild(header);
            rightDiv.appendChild(div);
        }

        const formDiv = document.createElement('div');
        formDiv.setAttribute('class', 'form-inline');
        formDiv.setAttribute('class', 'justify-content-center');
        formDiv.setAttribute('class', 'form-wrapper');
        formDiv.style.margin = "10px";

        const connectorInput = document.createElement('input');
        connectorInput.setAttribute('class', 'form-text');
        connectorInput.setAttribute('type', 'text');
        connectorInput.setAttribute('placeholder', 'Enter new connector name');
        connectorInput.setAttribute('id', 'add-connector-name');
        connectorInput.style.minWidth = "200px";
        connectorInput.style.margin = "10px";

        const addButton = document.createElement('button');
        addButton.setAttribute('class', 'btn btn-secondary');
        addButton.setAttribute('disabled', true);
        addButton.setAttribute('id', 'add-connector-btn');
        addButton.appendChild(document.createTextNode('Add Connector'));
        addButton.style.margin = "10px";
        
        connectorInput.addEventListener('input', (evt) => {
            if (String(connectorInput.value) != '' || connectorInput.value == null
                || connectorInput.value === undefined) {
                addButton.disabled = false; 
            } else {
                addButton.disabled = true;
            }
        });

        addButton.onclick = () => {
            const connectorName = connectorInput.value;

            body = JSON.stringify({
                cable_id: row.id,
                connectorName: connectorName
            })

            fetch('/addconnector', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: body
            }).then((res) => {
                if (res.status == 200) {
                    location.reload();
                } else {
                    alert('Failed to add cable. Please try again.');
                }
            })
        }

        formDiv.appendChild(connectorInput);
        formDiv.appendChild(addButton);
        rightDiv.appendChild(formDiv);
    }

    function fillColorData(data) {
        if (data.length > 0) {
            const header = document.createElement('h5');
            header.appendChild(document.createTextNode('Colors'));
            header.style.margin = '10px';
            rightDiv.appendChild(header);

            const table = document.createElement('table');
            table.id = 'color-table';
            const head = document.createElement('tr');
            const th1 = document.createElement('th');
            const th2 = document.createElement('th'); 
            th2.appendChild(document.createTextNode('Color'));
            head.appendChild(th1);
            head.appendChild(th2);

            table.appendChild(head);

            table.setAttribute('class', 'table-hover');
            table.setAttribute('class', 'table-striped');
            table.setAttribute('class', 'table-condensed');
            table.setAttribute('class', 'table-responsive');
            for (color of data) {
                var tr = document.createElement('tr'); 
                var deleteTd = document.createElement('td');

                var deleteButton = document.createElement('button');
                deleteButton.setAttribute('class', 'btn-close');
                deleteButton.setAttribute('type', 'button');
                deleteButton.onclick = () => {removeColor(row.id, color.id);}
                var span = document.createElement('span');
                span.setAttribute('class', 'icon-cross');
                deleteButton.appendChild(span);
                deleteTd.appendChild(deleteButton);

                var td1 = document.createElement('td');
                var td2 = document.createElement('td');  
                td1.appendChild(document.createTextNode(color.colorName));
                
                var colorDiv = document.createElement('div');
                colorDiv.setAttribute('class', 'color-box');
                colorDiv.style.background = `rgb(${color.redChannel}, ${color.blueChannel}, ${color.greenChannel})`;
                td2.append(colorDiv);
                
                tr.appendChild(deleteTd);
                tr.appendChild(td1);
                tr.appendChild(td2);

                tr.id = color.id;
                table.appendChild(tr);
            }
            rightDiv.appendChild(table);
        } else {
            const div = document.createElement('div');
            div.style.textAlign = "center";
            div.style.margin = "10px";
            div.style.marginTop = "50px";
            const header = document.createElement('h5');
            header.appendChild(document.createTextNode("No Colors :("));
            div.appendChild(header);
            rightDiv.appendChild(div);
        }

        const formDiv = document.createElement('div');
        formDiv.setAttribute('class', 'form-inline');
        formDiv.setAttribute('class', 'justify-content-center');
        formDiv.setAttribute('class', 'form-wrapper');
        formDiv.style.margin = "10px";

        const colorInput = document.createElement('input');
        colorInput.setAttribute('class', 'form-text');
        colorInput.setAttribute('type', 'text');
        colorInput.setAttribute('placeholder', 'Enter new color name');
        colorInput.setAttribute('id', 'add-color-name');
        colorInput.style.margin = "10px";

        const colorChooser = document.createElement('input');
        colorChooser.setAttribute('type', 'color');
        colorChooser.setAttribute('id', 'add-color-chooser');
        colorChooser.style.margin = "10px";

        const addButton = document.createElement('button');
        addButton.setAttribute('class', 'btn btn-secondary');
        addButton.setAttribute('id', 'add-color-btn');
        addButton.appendChild(document.createTextNode('Add Color'));
        addButton.setAttribute('disabled', true);
        addButton.style.margin = "10px";

        colorInput.addEventListener('input', (evt) => {
            if (String(colorInput.value) != '' || colorInput.value == null ||
            colorInput.value == undefined) {
                addButton.disabled = false;
            } else {
                addButton.disabled = true;
            }
        });

        addButton.onclick = () => {
            const colorName = colorInput.value;
            const colorHex = colorChooser.value;
            const rgb = hexToRgb(colorHex);

            body = JSON.stringify({
                cable_id: row.id,
                color_name: colorName,
                red_channel: rgb[0],
                green_channel: rgb[1],
                blue_channel: rgb[2]
            });
            
            fetch('/addcolor', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: body
            }).then((res) => {
                if (res.status == 200) {
                    location.reload();
                } else {
                    alert('Failed to add cable. Please try again.');
                }
            })

            // Courtesy of: https://stackoverflow.com/questions/65154794/how-can-i-get-the-rgb-values-from-color-picker-and-display-them
            function hexToRgb(hex) {
                return ['0x' + hex[1] + hex[2] | 0, '0x' + hex[3] + hex[4] | 0, '0x' + hex[5] + hex[6] | 0];
            }
        }
        
        formDiv.appendChild(colorInput);
        formDiv.appendChild(colorChooser);
        formDiv.appendChild(addButton);
        rightDiv.appendChild(formDiv);
    }

    function removeColor(cableId, colorId) {
        fetch('/removecolormapping', {
            headers: { 'Content-Type': 'application/json' },
            method: 'POST',
            body: JSON.stringify({
                'cable_id': cableId, 
                'color_id': colorId
            })
        }).then((res) => {
            if (res.status == 200) {
                populateTables(row);
            } else {
                alert('Unable to remove color.');
            }
        });
    }

    function removeConnector(cableId, connectorId) {
        fetch('/removeconnectormapping', {
            headers: { 'Content-Type': 'application/json' },
            method: 'POST',
            body: JSON.stringify({
                'cable_id': cableId, 
                'connector_id': connectorId
            })
        }).then((res) => {
            if (res.status == 200) {
                populateTables(row);
            }
        });
    }
}

let cableFields = [document.getElementById('add-desc'), document
    .getElementById('add-cable-type'), document
    .getElementById('add-cable-group'), document
    .getElementById('add-location'), document
    .getElementById('add-length')];

cableFields.forEach((input) => {
    input.addEventListener('input', (evt) => {
        let addDesc = cableFields[0].value;
        let addCableType = cableFields[1].value;
        let addCableGroup = cableFields[2].value;
        let addLocation = cableFields[3].value;
        let addLength = cableFields[4].value;

        if (!checkVal(addDesc) && !checkVal(addCableType) && 
            !checkVal(addCableGroup) && !checkVal(addLocation) && 
            !checkVal(addLength)) {
            document.getElementById('add-new-cable-btn').disabled = false;
        } else {
            document.getElementById('add-new-cable-btn').disabled = true;
        }

        function checkVal(val) {
            return (val == '' || val == undefined || val == null);
        }
    });
})

function sendNewCableRequest() {
    let addDesc = cableFields[0].value;
    let addCableType = cableFields[1].value;
    let addCableGroup = String(cableFields[2].value);
    let addLocation = cableFields[3].value;
    let addLength = cableFields[4].value;

    if (addCableGroup == 'DISPLAY_CABLE' || addCableGroup == 'AUDIO_CABLE' ||
        addCableGroup == 'DATA_CABLE' || addCableGroup == 'POWER_CABLE') {
        data = JSON.stringify({
            description: addDesc,
            cable_type: addCableType,
            cable_group: addCableGroup,
            location: addLocation,
            length: addLength
        });
    
        fetch('/addcable', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: data
        }).then((res) => {
            if (res.status == 200) {
                location.reload();
            } else {
                alert('Unable to add new cable. Please try again.');
            }
        })
    } else {
        alert('Invalid Cable Group. Please select one from the list.');
        return;
    }
}

function removeCable(btn) {
    const cableID = btn.id;

    fetch('/removecable', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({cable_id: cableID})
    }).then((res) => {
        if (res.status == 200) {
            location.reload();
        } else {
            alert('Unable to remove cable.');
        }
    })
}