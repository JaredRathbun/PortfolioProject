package com.rathbunj.repository.mappers;

import com.rathbunj.entity.CableType;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class CableTypeMapper implements RowMapper<CableType> {
    @Override
    public CableType mapRow(ResultSet rs, int rowNum) throws SQLException {
        return new CableType(rs.getInt("ID"), rs
                .getString("TypeName"));
    }
}
