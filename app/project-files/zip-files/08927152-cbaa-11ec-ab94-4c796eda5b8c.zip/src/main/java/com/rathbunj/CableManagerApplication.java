package com.rathbunj;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;

@SpringBootApplication
public class CableManagerApplication implements CommandLineRunner {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * Logging object.
	 */
	private final static Logger logger = LogManager
			.getLogger(CableManagerApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(CableManagerApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		if (args.length == 1) {
			if (args[0].equals("--sampledata")) {
				try {
					jdbcTemplate.execute("{CALL insertSampleData()}");
				} catch (Exception ex) {
					logger.fatal("Unable to execute sample data stored " + 
						"procedure. Consider clearing the database of all " + 
						"contents.");
					System.exit(1);
				}
			}
		}
	}
}
