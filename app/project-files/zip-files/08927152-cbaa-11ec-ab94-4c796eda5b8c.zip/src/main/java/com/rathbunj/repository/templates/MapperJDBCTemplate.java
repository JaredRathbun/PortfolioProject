package com.rathbunj.repository.templates;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class MapperJDBCTemplate {
    
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public boolean removeCableConnectorMapping(final int cableID,
         final int connectorID) {
        assert (cableID > 0 && connectorID > 0);

        if (cableID < 0) {
            throw new IllegalArgumentException("cableID must be > 0.");
        }

        if (connectorID < 0) {
            throw new IllegalArgumentException("connectorID must be > 0.");
        }

        jdbcTemplate.update("{CALL removeCableConnectorMappingEntry" +
            "(?, ?, @rowsEffected)}", cableID, connectorID);
        return (jdbcTemplate.queryForObject("{CALL getRowsEffected()}", 
            Integer.class) > 0);
    }

    public boolean removeCableColorMapping(final int cableID,
         final int colorID) {
        assert (cableID > -1 && colorID > -1);

        if (cableID < 0) {
            throw new IllegalArgumentException("cableID must be > 0.");
        }

        if (colorID < 0) {
            throw new IllegalArgumentException("colorID must be > 0.");
        }

        jdbcTemplate.update("{CALL removeCableColorMappingEntry" +
            "(?, ?, @rowsEffected)}", cableID, colorID);
        return (jdbcTemplate.queryForObject("{CALL getRowsEffected()}", 
            Integer.class) > 0);
    }

    public boolean addCableColorMapping(final int cableID, final int colorID) {
        assert (cableID > -1 && colorID > -1);

        if (cableID < 0) {
            throw new IllegalArgumentException("cableID must be > 0.");
        }

        if (colorID < 0) {
            throw new IllegalArgumentException("colorID must be > 0.");
        }

        return (jdbcTemplate.update("{CALL addCableColorMappingEntry(?, ?)}", 
            cableID, colorID) > 0);
    }

    public boolean addCableConnectorMapping(final int cableID, 
        final int connectorID) {
        assert (cableID > -1 && connectorID > -1);

        if (cableID < 0) {
            throw new IllegalArgumentException("cableID must be > 0.");
        }

        if (connectorID < 0) {
            throw new IllegalArgumentException("colorID must be > 0.");
        }

        return (jdbcTemplate
            .update("{CALL addCableConnectorMappingEntry(?, ?)}", cableID, 
            connectorID) > 0);
    }
}
