package com.rathbunj.repository.templates;

import com.rathbunj.entity.CableType;
import com.rathbunj.repository.mappers.CableTypeMapper;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.CallableStatement;
import java.util.List;

@Repository
public class CableTypeJDBCTemplate {

    private static final Logger logger = LogManager
        .getLogger(CableTypeJDBCTemplate.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Autowired
    private CableTypeMapper cableTypeMapper;

    public CableType findById(Integer ID) {
        final String QUERY = "{CALL getCableTypeByID(?)}";
        
        try {
            return jdbcTemplate.queryForObject(QUERY, cableTypeMapper, ID);
        } catch (EmptyResultDataAccessException ex) {
            return null;
        }
    }

    public CableType findByCableTypeName(String cableTypeName) {
        final String QUERY = "{CALL getCableTypeByTypeName(?)}";
        try {
            return jdbcTemplate.queryForObject(QUERY, cableTypeMapper, 
                cableTypeName);
        } catch (EmptyResultDataAccessException ex) {
            return null;
        }
    }

    public List<CableType> findAll() {
        final String QUERY = "{CALL getAllCableTypes()}";
        return jdbcTemplate.query(QUERY, cableTypeMapper);
    }


    public int save(String cableTypeName) {
        assert (cableTypeName != null);

        if (cableTypeName == null || cableTypeName.equals("")) {
            throw new IllegalArgumentException("CableType was empty or null.");
        }

        jdbcTemplate.update("{CALL addCableType(?, @ID)}", cableTypeName);
        return jdbcTemplate.queryForObject("{CALL getID()}", 
            Integer.class);
    }

    public CableType getCableTypeObject(Object cableTypeName) {
        String cableTypeString = (String) cableTypeName;

        CallableStatement procCall = null;
        Connection conn = null;

        try {
            conn = jdbcTemplate.getDataSource().getConnection();
            procCall = conn.prepareCall("{CALL cableTypeExists(?)}");
            procCall.setString(1, cableTypeString);
            ResultSet rs = procCall.executeQuery();

            if (rs.next()) {
                boolean locExists = rs.getString("result").equals("1");
                
                if (locExists) {
                    return findByCableTypeName(cableTypeString);
                } else {
                    final int newCableTypeID = save(cableTypeString);
                    return new CableType(newCableTypeID, cableTypeString);
                }
            } 
        } catch (SQLException ex) {
            logger.error("Unable to execute stored procedure.", ex);
        } finally {
            try {
                procCall.close();
                conn.close();
            } catch (SQLException ex) {
                logger.error("Unable to close connection object.", ex);
            }
        }

        return null;
    }
}
