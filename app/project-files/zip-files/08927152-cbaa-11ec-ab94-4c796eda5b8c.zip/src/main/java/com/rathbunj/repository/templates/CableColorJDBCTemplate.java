package com.rathbunj.repository.templates;

import com.rathbunj.entity.CableColor;
import com.rathbunj.repository.mappers.CableColorMapper;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CableColorJDBCTemplate  {

    private static final Logger logger = LogManager
        .getLogger(CableColorJDBCTemplate.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private CableColorMapper cableColorMapper;

    public CableColor findById(Integer integer) {
        return null;
    }

    public List<CableColor> findAll() {
        final String QUERY = "{CALL getAllColors()}";
        return jdbcTemplate.query(QUERY, cableColorMapper);
    }

    public CableColor findColorByName(String colorName) {
        final String QUERY = "{CALL getColorByName(?)}";
        return jdbcTemplate.queryForObject(QUERY, cableColorMapper, colorName);
    }

    public boolean delete(CableColor entity) {
        if (entity == null) {
            throw new IllegalArgumentException("CableColor entity was null");
        }

        return deleteById(entity.getID());
    }

    public boolean deleteById(int ID) {
        if (ID < 0) {
            throw new IllegalArgumentException("ID must be > 0");
        }

        jdbcTemplate.update("{CALL removeColor(?, @rowsEffected)}", ID);
        return jdbcTemplate.queryForObject("{CALL getRowsEffected()}",
            Integer.class) > 0;
    }

    public Iterable<CableColor> findAllById(Iterable<Integer> ids) {
        final ArrayList<CableColor> returnList = new ArrayList<>();
        final String QUERY = "{CALL getAllColorsByID(?)}";

        for (final Integer id : ids) {
            returnList.addAll(jdbcTemplate.query(QUERY, cableColorMapper,
                    new Object[] {id}));
        }

        return returnList;
    }

    public int save(String colorName, int red, int green, int blue) 
        throws SQLException {
        assert (colorName != null);

        if (colorName == null) {
            throw new IllegalArgumentException("CableColor entity was null.");
        }

        if (red < 0 || red > 255) {
            throw new IllegalArgumentException("Red channel must be between 0 "
                 + "and 255.");
        }

        if (green < 0 || green > 255) {
            throw new IllegalArgumentException("Green channel must be between 0"
                 + " and 255.");
        }

        if (blue < 0 || blue > 255) {
            throw new IllegalArgumentException("Blue  channel must be between 0"
                 + " and 255.");
        }

        String QUERY = "{CALL addColor(?, ?, ?, ?)}";

        CallableStatement procCall = null;
        Connection conn = null;

        conn = jdbcTemplate.getDataSource().getConnection();
        procCall = conn.prepareCall(QUERY);
        
        procCall.setString(1, colorName);
        procCall.setInt(2, red);
        procCall.setInt(3, green);
        procCall.setInt(4, blue);

        ResultSet rs = procCall.executeQuery();

        if (rs.next()) {
            return rs.getInt("ID");
        }

        try {
            procCall.close();
            conn.close();
        } catch (SQLException ex) {
            logger.error("Unable to close Connection/CallableStatement " +
                "object.", ex);
        }

        return -1;
    }

    /**
     * Returns an array of {@code CableColor} objects that correspond the given
     * cable ID.
     * 
     * @param cableID The ID of the cable to get the colors for.
     * @return An array of {@code CableColor} objects that correspond to the 
     * cable.
     */
    public CableColor[] getCableColorArray(final int cableID) {
        final String QUERY = "{CALL getAllColorsByID(?)}";
        return jdbcTemplate.query(QUERY, cableColorMapper,
                new Object[] {cableID}).toArray(new CableColor[0]);
    }

    public CableColor getCableColorObject(Object colorName, int red, int green, 
        int blue) {
        String colName = (String) colorName;

        CallableStatement procCall = null;
        Connection conn = null;

        try {
            conn = jdbcTemplate.getDataSource().getConnection();
            procCall = conn.prepareCall("{CALL colorExists(?)}");
            procCall.setString(1, colName);
            ResultSet rs = procCall.executeQuery();

            if (rs.next()) {
                boolean locExists = rs.getString("result").equals("1");
            
                if (locExists) {
                    return findColorByName(colName);
                } else {
                    final int newCableColorID = save(colName, red, green, blue);
                    return new CableColor(newCableColorID, colName, red, green, 
                        blue);
                }
            } 
        } catch (SQLException ex) {
            logger.error("Unable to execute stored procedure.", ex);
        } finally {
            try {
                procCall.close();
                conn.close();
            } catch (SQLException ex) {
                logger.error("Unable to close connection object.", ex);
            }
        }

        return null;
    }
}
