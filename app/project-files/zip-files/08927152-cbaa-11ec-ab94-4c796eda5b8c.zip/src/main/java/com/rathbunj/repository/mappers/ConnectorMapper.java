package com.rathbunj.repository.mappers;

import com.rathbunj.entity.Connector;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class ConnectorMapper implements RowMapper<Connector> {
    @Override
    public Connector mapRow(ResultSet rs, int rowNum) throws SQLException {
        return new Connector(rs.getInt("ID"), rs
                .getString("ConnectorName"));
    }
}
