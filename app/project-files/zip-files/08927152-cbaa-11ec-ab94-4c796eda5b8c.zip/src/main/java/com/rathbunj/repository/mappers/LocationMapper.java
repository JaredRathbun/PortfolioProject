package com.rathbunj.repository.mappers;

import com.rathbunj.entity.Location;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class LocationMapper implements RowMapper<Location> {
    @Override
    public Location mapRow(ResultSet rs, int rowNum) throws SQLException {
        return new Location(rs.getInt("ID"), rs
                .getString("LocationName"));
    }
}
