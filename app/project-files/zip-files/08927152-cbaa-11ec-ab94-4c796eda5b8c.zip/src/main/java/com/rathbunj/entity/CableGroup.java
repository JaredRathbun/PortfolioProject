package com.rathbunj.entity;

public enum CableGroup {
    /**
     * A display Cable
     */
    DISPLAY_CABLE {
        public String toString() {
            return "DISPLAY_CABLE";
        }
    },

    /**
     * An audio cable.
     */
    AUDIO_CABLE {
        public String toString() {
            return "AUDIO_CABLE";
        }
    },

    /**
     * A data cable.
     */
    DATA_CABLE {
        public String toString() {
            return "DATA_CABLE";
        }
    },

    /**
     * A power cable.
     */
    POWER_CABLE {
        public String toString() {
            return "POWER_CABLE";
        }
    }

}
