package com.rathbunj.entity;

import org.springframework.data.annotation.Id;

public class Location {

    @Id
    private Integer ID;
    private String locationName;

    public Location(Integer ID, String locationName) {
        this.ID = ID;
        this.locationName = locationName;
    }

    public int getID() {
        return ID;
    }

    public String getLocationName() {
        return this.locationName;
    }
}
