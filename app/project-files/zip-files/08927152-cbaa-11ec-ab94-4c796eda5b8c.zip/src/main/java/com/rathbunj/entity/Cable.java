package com.rathbunj.entity;

import org.springframework.data.annotation.Id;

import java.util.Date;

public class Cable {
    @Id
    private final Integer ID;
    private final String cableDescription;
    private final CableType cableType;

    private final Date dateAdded;
    private final double length;
    private final CableGroup cableGroup;
    private final Location location;
    private final Connector[] connectors;
    private final CableColor[] cableColors;

    public Cable(Integer ID, String cableDescription, CableType cableType,
                 double length, Long dateAdded, CableGroup cableGroup,
                 Location location, Connector[] connectors, CableColor[]
                 cableColors) {
        this.ID = ID;
        this.cableDescription = cableDescription;
        this.cableType = cableType;
        this.length = length;
        this.dateAdded = convertDate(dateAdded);
        this.cableGroup = cableGroup;
        this.location = location;
        this.connectors = connectors;
        this.cableColors = cableColors;
    }

    /**
     * Converts a {@code Long} that represents milliseconds since January 1,
     * 1970 into a {@code java.util.Date} object.
     *
     * @param date The number of milliseconds since 1-1-1970
     * @return A Date object.
     */
    public Date convertDate(Long date) {

        if (date == null) {
            return null;
        } else {
            return new Date(date);
        }
    }

    public Integer getID() {
        return ID;
    }

    public String getCableDescription() {
        return cableDescription;
    }

    public CableType getCableType() {
        return cableType;
    }

    /**
     * Returns the date the cable was added.
     *
     * @return A date object representing the date the cable was added.
     */
    public Date getDateAdded() {
        return dateAdded;
    }

    public double getLength() {
        return length;
    }

    public Location getLocation() {
        return location;
    }

    public Connector[] getConnectors() {
        return connectors;
    }

    public CableGroup getCableGroup() {
        return cableGroup;
    }

    public CableColor[] getCableColors() {
        return cableColors;
    }
//
//    @Override
//    public String toString() {
//        return String.format("Cable(ID=%d, description=%s, cableType=%s, " +
//                "length=%.2f in., dateAdded=%s, cableGroup=%s,  location=%s, " +
//                "connectors=%s, cableColors=%s)", ID, cableDescription,
//                cableType, length, new SimpleDateFormat("MMMM dd, " +
//                "yyyy hh:mma").format(dateAdded), cableGroup, location,
//                connectors, cableColors);
//    }
}
