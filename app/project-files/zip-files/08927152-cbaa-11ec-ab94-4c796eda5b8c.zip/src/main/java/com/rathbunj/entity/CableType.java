package com.rathbunj.entity;

import org.springframework.data.annotation.Id;

public class CableType {
    @Id
    private Integer ID;
    private String typeName;

    public CableType(Integer ID, String typeName) {
        this.ID = ID;
        this.typeName = typeName;
    }

    public Integer getID() {
        return ID;
    }

    public void setID(Integer ID) {
        this.ID = ID;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }
}
