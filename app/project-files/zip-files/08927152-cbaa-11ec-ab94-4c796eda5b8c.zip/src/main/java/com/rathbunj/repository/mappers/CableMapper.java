package com.rathbunj.repository.mappers;

import com.rathbunj.entity.*;
import com.rathbunj.repository.templates.CableColorJDBCTemplate;
import com.rathbunj.repository.templates.CableTypeJDBCTemplate;
import com.rathbunj.repository.templates.ConnectorJDBCTemplate;
import com.rathbunj.repository.templates.LocationJDBCTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class CableMapper implements RowMapper<Cable> {
    @Autowired
    private LocationJDBCTemplate locationRepo;

    @Autowired
    private ConnectorJDBCTemplate connectorRepo;

    @Autowired
    private CableTypeJDBCTemplate cableTypeRepo;

    @Autowired
    private CableColorJDBCTemplate cableColorRepo;

    @Override
    public Cable mapRow(ResultSet rs, int rowNum) throws SQLException {
        final int ID = rs.getInt("ID");
        final CableGroup CABLE_GROUP = getCableGroup(rs
                .getString("CableGroup"));
        final Location LOCATION = getLocation(rs
                .getInt("LocationID"));
        final Connector[] CONNECTORS = getConnectors(ID);
        final CableType CABLE_TYPE = getCableType(rs
                .getInt("CableType"));
        final CableColor[] CABLE_COLORS = getCableColors(ID);

        return new Cable(ID, rs.getString("CableDescription"),
                CABLE_TYPE, rs.getDouble("Length"), rs
                .getTimestamp("DateAdded").getTime(), CABLE_GROUP,
                LOCATION, CONNECTORS, CABLE_COLORS);
    }
    
    private CableGroup getCableGroup(String cableGroup) {
        assert (cableGroup != null && !cableGroup.equals(""));

        switch (cableGroup) {
            case "DISPLAY_CABLE":
                return CableGroup.DISPLAY_CABLE;
            case "AUDIO_CABLE":
                return CableGroup.AUDIO_CABLE;
            case "DATA_CABLE":
                return CableGroup.DATA_CABLE;
            case "POWER_CABLE":
                return CableGroup.POWER_CABLE;
        }

        return null;
    }

    private Location getLocation(int locationID) {
        if (locationID < 0) {
            throw new IllegalArgumentException("Invalid ID given.");
        }

        return locationRepo.findById(locationID);
    }

    private Connector[] getConnectors(int cableID) {
        if (cableID < 0) {
            throw new IllegalArgumentException("Invalid ID given.");
        }

        return connectorRepo.getConnectorArrayById(cableID);
    }

    private CableType getCableType(int cableType) {
        return cableTypeRepo.findById(cableType);
    }

    private CableColor[] getCableColors(int cableID) {
        if (cableID < 0) {
            throw new IllegalArgumentException("Invalid ID given.");
        }

        return cableColorRepo.getCableColorArray(cableID);
    }
}
