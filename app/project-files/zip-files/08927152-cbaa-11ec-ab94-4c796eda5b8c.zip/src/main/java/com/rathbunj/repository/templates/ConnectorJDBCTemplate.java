package com.rathbunj.repository.templates;

import com.rathbunj.entity.Connector;
import com.rathbunj.repository.mappers.ConnectorMapper;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class ConnectorJDBCTemplate {

    private static final Logger logger = LogManager
        .getLogger(ConnectorJDBCTemplate.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private ConnectorMapper connectorMapper;

    public Connector findById(Integer id) {
        final String QUERY = "{CALL getConnectorByID(?)}";
        return jdbcTemplate.queryForObject(QUERY, connectorMapper, 
                new Object[]{id});
    }

    public List<Connector> findAll() {
        final String QUERY = "{CALL getAllConnectors()}";
        return jdbcTemplate.query(QUERY, connectorMapper);
    }

    public Connector findByConnectorName(final String connectorName) {
        final String QUERY = "{CALL getConnectorByName(?)}";
        return jdbcTemplate.queryForObject(QUERY, connectorMapper, 
            connectorName);
    }

    public boolean deleteById(int ID) {
        if (ID < 0) {
            throw new IllegalArgumentException("ID was < 0. ");
        }

        jdbcTemplate.update("{CALL removeConnector(?, @rowsEffected)}", 
            ID);
        return jdbcTemplate.queryForObject("{CALL getRowsEffected()}",
            Integer.class) > 0;
    }

    public int save(String connectorName) {
        assert (connectorName != null && !connectorName.equals(""));

        if (connectorName == null || connectorName.equals("")) {
            throw new IllegalArgumentException("Connector entity was null.");
        }

        jdbcTemplate.update("{CALL addConnector(?, @ID)}", connectorName);
        return jdbcTemplate.queryForObject("{CALL getID()}", 
            Integer.class);
    }

    public Connector[] getConnectorArrayById(Integer cableID) {
        final String QUERY = "{CALL getAllConnectorsByID(?)}";
        return jdbcTemplate.query(QUERY, connectorMapper,
                new Object[]{cableID}).toArray(new Connector[0]);
    }

    public Connector getConnectorObject(Object connectorName) {
        String connName = (String) connectorName;

        CallableStatement procCall = null;
        Connection conn = null;

        try {
            conn = jdbcTemplate.getDataSource().getConnection();
            procCall = conn.prepareCall("{CALL connectorExists(?)}");
            procCall.setString(1, connName);
            ResultSet rs = procCall.executeQuery();

            if (rs.next()) {
                boolean locExists = rs.getString("result").equals("1");
                if (locExists) {
                    return findByConnectorName(connName);
                } else {
                    final int newConnectorID = save(connName);
                    return new Connector(newConnectorID, connName);
                }
            } 
        } catch (SQLException ex) {
            logger.error("Unable to execute stored procedure.", ex);
        } finally {
            try {
                procCall.close();
                conn.close();
            } catch (SQLException ex) {
                logger.error("Unable to close connection object.", ex);
            }
        }

        return null;
    
    }
}
