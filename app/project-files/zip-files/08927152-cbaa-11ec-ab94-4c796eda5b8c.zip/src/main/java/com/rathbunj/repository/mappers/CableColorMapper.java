package com.rathbunj.repository.mappers;

import com.rathbunj.entity.CableColor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class CableColorMapper implements RowMapper<CableColor> {
    @Override
    public CableColor mapRow(ResultSet rs, int rowNum) throws SQLException {
        return new CableColor(rs.getInt("ID"), rs
                .getString("ColorName"), rs
                .getInt("RedChannel"), rs
                .getInt("BlueChannel"), rs
                .getInt("GreenChannel"));
    }
}
