package com.rathbunj.repository.templates;

import com.rathbunj.entity.Cable;
import com.rathbunj.repository.mappers.CableMapper;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository
public class CableJDBCTemplate  {

    private static final Logger logger = LogManager.getLogger(CableJDBCTemplate
        .class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private CableMapper cableMapper;

    /**
     * Returns the {@code Cable} object that corresponds to the ID given.
     * 
     * @param ID An integer representing the ID of the cable.
     * @return A {@code Cable} object representing the cable that corresponds to
     * the given ID.
     */
    public Cable findById(Integer ID) {
        final String QUERY = "{CALL getCableByID(?)}";
        try {
            Cable res = jdbcTemplate.queryForObject(QUERY, cableMapper, ID);
            System.out.println(res);
            return res;
        } catch (EmptyResultDataAccessException ex) {
            return null;
        }

    }

    /**
     * Returns a {@code List<Cable>} containing all of the cables in the
     * database.
     * 
     * @return A {@code List<Cable>} containing allof the cables in the 
     * database.
     */
    public List<Cable> findAll() {
        return jdbcTemplate.query("{CALL getAllCables()}", cableMapper);
    }

    /**
     * Deletes a given cable from the database with the specified ID.
     *
     * @param ID The integer ID of the cable.
     */
    public boolean deleteById(int ID) {
        if (ID < 0) {
            throw new IllegalArgumentException("ID must be > 0");
        }

        jdbcTemplate.update("{CALL removeCable(?, @rowsEffected)}", ID);
        return jdbcTemplate.queryForObject("{CALL getRowsEffected()}",
            Integer.class) > 0;
    }

    /**
     * Returns all {@code Cable} objects whose ID match one of the specified.
     *
     * @param ids An {@code Iterable<Integer>} of IDs.
     * @return An {@code Iterable<Cable>} of Cables whose ID matches one of the
     * specified.
     */
    public Iterable<Cable> findAllById(Iterable<Integer> ids) {
        List<Cable> returnList = new ArrayList<>();

        ids.forEach((id) -> {
            Cable result = findById(id);

            if (result != null) {
                returnList.add(result);
            }
        });

        return returnList;
    }

    public boolean save(Cable entity) throws SQLException {
        final String QUERY = "{CALL addCable(?, ?, ?, ?, ?)}";

        CallableStatement procCall = null;
        Connection conn = null;

        conn = jdbcTemplate.getDataSource().getConnection();
        procCall = conn.prepareCall(QUERY);
        
        procCall.setString(1, entity.getCableDescription());
        procCall.setInt(2, entity.getCableType().getID());
        procCall.setDouble(3, entity.getLength());
        procCall.setInt(4, entity.getLocation().getID());
        procCall.setString(5, entity.getCableGroup().toString());
        
        boolean wasSuccessful = procCall.execute();

        try {
            procCall.close();
            conn.close();
        } catch (SQLException ex) {
            logger.error("Unable to close Connection/CallableStatement " +
                "object.", ex);
        }
        
        return wasSuccessful;
    }

    /**
     * Saves all {@code Cable} objects inside of an {@code Iterable<Cable>}.
     * 
     * @param entities The {@code Iterable<Cable>} of Cable objects to save.
     */
    public void saveAll(Iterable<Cable> entities) {
        // If the list is null, throw an exception.
        if (entities == null) {
            throw new IllegalArgumentException("Entities list was null.");
        }

        // Attempt to save each cable, throwing an exception if it is null.
        entities.forEach((cable) -> {
            if (cable == null) {
                throw new NullPointerException("Cable was null.");
            } else {
                try {
                    save(cable);
                } catch (SQLException e) {
                    logger.error("Unable to save cable with ID = " + 
                        cable.getID() + ".");
                }
            }
        });
    }
}
