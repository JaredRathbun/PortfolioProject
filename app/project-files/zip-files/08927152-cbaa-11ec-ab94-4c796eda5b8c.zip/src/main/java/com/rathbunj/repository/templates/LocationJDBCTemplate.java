package com.rathbunj.repository.templates;

import com.rathbunj.entity.Location;
import com.rathbunj.repository.mappers.LocationMapper;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class LocationJDBCTemplate {

    /**
     * Logging object.
     */
    private static final Logger logger = LogManager
        .getLogger(LocationJDBCTemplate.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private LocationMapper locationMapper;

    public Location findById(Integer ID) {
        final String QUERY = "{CALL getLocationByID(?)}";
        return jdbcTemplate.queryForObject(QUERY, locationMapper, ID);
    }

    public List<Location> findAll() {
        final String QUERY = "{CALL getAllLocations()}";
        return jdbcTemplate.query(QUERY, locationMapper);
    }

    public boolean delete(Location entity) {
        if (entity == null) {
            throw new IllegalArgumentException("Location entity was null.");
        }

        return deleteById(entity.getID());
    }

    public Location findByLocationName(String locationName) {
        assert (locationName != null && !locationName.equals(""));

        if (locationName == null || locationName.equals("")) {
            throw new IllegalArgumentException("LocationName must not be " +
                    "null or empty.");
        }

        final String QUERY = "{CALL getLocationByName(?)}";
        return jdbcTemplate.queryForObject(QUERY, locationMapper, locationName);
    }

    public boolean deleteById(int ID) {
        if (ID < 0) {
            throw new IllegalArgumentException("ID was < 0. ");
        }

        jdbcTemplate.update("{CALL removeLocation(?, @rowsEffected)}", ID);
        return jdbcTemplate.queryForObject("{CALL getRowsEffected()}",
            Integer.class) > 0;
    }

    public int save(String location) {
        assert (location != null);

        if (location == null || location.equals("")) {
            throw new IllegalArgumentException("Location was empty or null.");
        }

        jdbcTemplate.update("{CALL addLocation(?, @ID)}", location);
        return jdbcTemplate.queryForObject("{CALL getID()}", Integer.class);
    }

    public Location getLocationObject(Object locationName) {
        String locName = (String) locationName;

        CallableStatement procCall = null;
        Connection conn = null;

        try {
            conn = jdbcTemplate.getDataSource().getConnection();
            procCall = conn.prepareCall("{CALL locationExists(?)}");
            procCall.setString(1, locName);
            ResultSet rs = procCall.executeQuery();

            if (rs.next()) {
                boolean locExists = rs.getString("result").equals("1");
            
                if (locExists) {
                    return findByLocationName(locName);
                } else {
                    final int newLocationID = save(locName);
                    return new Location(newLocationID, locName);
                }
            } 
        } catch (SQLException ex) {
            logger.error("Unable to execute stored procedure.", ex);
        } finally {
            try {
                procCall.close();
                conn.close();
            } catch (SQLException ex) {
                logger.error("Unable to close connection object.", ex);
            }
        }

        return null;
    }
}
