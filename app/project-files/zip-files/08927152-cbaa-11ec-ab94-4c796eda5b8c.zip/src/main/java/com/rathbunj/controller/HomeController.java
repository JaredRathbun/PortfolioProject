package com.rathbunj.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.rathbunj.entity.*;
import com.rathbunj.repository.templates.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Controls all endpoint interaction with users.
 */
@Controller
public class HomeController {

    private static final Logger logger = LoggerFactory
            .getLogger(HomeController.class);

    @Autowired
    private CableJDBCTemplate cableTemplate;

    @Autowired
    private ConnectorJDBCTemplate connectorTemplate;

    @Autowired
    private CableColorJDBCTemplate colorTemplate;

    @Autowired
    private MapperJDBCTemplate mapperTemplate;

    @Autowired
    private LocationJDBCTemplate locationTemplate;

    @Autowired
    private CableTypeJDBCTemplate cableTypeTemplate;

    /**
     * Endpoint for the main page. Renders index.html.
     * 
     * @param model The model object to apply information to.
     * @return A string containing the file to render.
     */
    @GetMapping("/")
    public String index(final Model model) {
        List<Cable> cables = cableTemplate.findAll();

        model.addAttribute("cables", cables);
        return "index";
    }

    @PostMapping("/addcable")
    public ResponseEntity<String> addCable(
                @RequestBody Map<String, Object> body) {
        assert (body != null);

        if (body.containsKey("description") && body.containsKey("cable_type") 
            && body.containsKey("cable_group") && body.containsKey("length") 
            && body.containsKey("location")) {

            // Get the data from the body, then create a new cable object.
            String desc = String.valueOf(body.get("description"));
            CableGroup cableGroup = parseCableGroup(body.get("cable_group"));
            Location location = locationTemplate
                .getLocationObject(body.get("location"));
            double length = Double.valueOf(String.valueOf(body.get("length")));
            CableType cableType = cableTypeTemplate.getCableTypeObject(body
                    .get("cable_type"));

            // If the cable group was unable to be parsed, it's a 400.
            if (cableGroup == null)
                return ResponseEntity.badRequest()
                    .body("Invalid CableGroup.");
            
            // If the location was unable to be found, return a 400.
            if (location == null) {
                return ResponseEntity.badRequest()
                    .body("Unable to find location in database.");
            }
                
            Cable newCable = new Cable(null, desc, cableType, length,
            null, cableGroup, location, null, null);
            try {
                if (cableTemplate.save(newCable)) {
                    return ResponseEntity.ok().build();
                } else {
                    return ResponseEntity.internalServerError().build();
                }
                
            } catch (SQLException ex) {
                logger.trace("Failed to add new cable. ");
                return ResponseEntity.internalServerError().build();
            }
        }
           
        return ResponseEntity.badRequest().body("Missing field(s).");
        
    }

    @PostMapping("/addconnector")
    public ResponseEntity<String> addConnector(@RequestBody Map<String, 
        Object> body) {
        assert (body != null);

        if (body.containsKey("cable_id") && body.containsKey("connectorName")) {
            int cableID = parseIntFromObject(body.get("cable_id"));
            Object connectorName = body.get("connectorName");

            int connectorID = connectorTemplate
                .getConnectorObject(connectorName).getID();
            if (mapperTemplate.addCableConnectorMapping(cableID, connectorID)) {  
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.badRequest().body("Unable to insert" + 
                    " connector.");
            }

        }
        
        return ResponseEntity.badRequest().body("Missing field(s)");
        
    }

    @PostMapping("/addcolor")
    public ResponseEntity<String> addColor(@RequestBody Map<String, Object> 
        body) {
        assert (body != null);

        if (body.containsKey("cable_id") && body.containsKey("color_name") &&
            body.containsKey("red_channel") && body.containsKey("green_channel") 
            && body.containsKey("blue_channel")) {
            
            final int cableID = parseIntFromObject(body.get("cable_id")), 
                red = parseIntFromObject(body.get("red_channel")), 
                green = parseIntFromObject(body.get("green_channel")),
                blue = parseIntFromObject(body.get("blue_channel"));
            Object colorName = body.get("color_name");

            /* Get the ID that corresponds with the colorName and RGB values.*/
            final int colorID = colorTemplate.getCableColorObject(colorName, 
                red, green, blue).getID();
            
            // Map the cable and color together.
            return (mapperTemplate.addCableColorMapping(cableID, colorID)) ?
                ResponseEntity.ok().build() : ResponseEntity.badRequest()
                    .body("Unable to add color or map cable and color " + 
                        "together.");
        }

        return ResponseEntity.badRequest().body("Missing field(s).");
    }

    @PostMapping("/removecable")
    public ResponseEntity<String> removeCable(@RequestBody Map<String, Object> 
        body) {
        assert (body != null);

        if (body.containsKey("cable_id")) {
            if (cableTemplate.deleteById(parseIntFromObject(body
                .get("cable_id")))) {
                return ResponseEntity.ok().build();
            } else {
                System.out.println("in else");
                return ResponseEntity.badRequest().body("Unable to remove" + 
                    " entry from database.");
            }
        }
        
        return ResponseEntity.badRequest().body("Missing cable_id.");

    }

    @PostMapping("/removeconnectormapping")
    public ResponseEntity<String> removeConnectorMapping(
        @RequestBody Map<String, Object> body) {
        assert (body != null);

        if (body.containsKey("cable_id") && body.containsKey("connector_id")) {
            final int cableID = parseIntFromObject(body.get("cable_id")), 
                connectorID = parseIntFromObject(body.get("connector_id"));
            if (mapperTemplate
                .removeCableConnectorMapping(cableID, connectorID)) {
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.badRequest().body("Unable to remove " + 
                    "entry from database.");
            }
        }
        
        return ResponseEntity.badRequest().body("Missing cable_id or " + 
            "connector_id.");

    }

    @PostMapping("/removecolormapping")
    public ResponseEntity<String> removeColor(@RequestBody Map<String, Object> 
        body) {
        assert (body != null);

        if (body.containsKey("cable_id") && body.containsKey("color_id")) {
            final int cableID = parseIntFromObject(body.get("cable_id")), 
                colorID = parseIntFromObject(body.get("color_id"));
            boolean colorRemoved = mapperTemplate
                .removeCableColorMapping(cableID, colorID);
            if (colorRemoved) {
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.badRequest()
                    .body("Unable to remove entry from database.");
            }
        }
        
        return ResponseEntity.badRequest()
            .body("Missing cable_id or color_id.");

    }

    @GetMapping("/getconnectors/{id}")
    public ResponseEntity<Connector[]> getAllConnectors(@PathVariable int id) {
        Connector[] foundConnectors = connectorTemplate
                .getConnectorArrayById(id);
        return ResponseEntity.ok().body(foundConnectors);
    }

    @GetMapping("/getcolors/{id}")
    public ResponseEntity<CableColor[]> getAllColors(@PathVariable int id) {
        CableColor[] cableColors = colorTemplate.getCableColorArray(id);
        return ResponseEntity.ok().body(cableColors);
    }

    private Integer parseIntFromObject(Object val) {
        try {
            return (val == null) ? null : Integer.valueOf(String.valueOf(val));
        } catch (NumberFormatException ex) {
            logger.error("Unable to parse int value: " + val, ex);
            return null;
        }
    }

    private CableGroup parseCableGroup(Object rawCableGroup) {
        switch ((String) rawCableGroup) {
            case "DISPLAY_CABLE":
                return CableGroup.DISPLAY_CABLE;
            case "AUDIO_CABLE":
                return CableGroup.AUDIO_CABLE;
            case "DATA_CABLE":
                return CableGroup.DATA_CABLE;
            case "POWER_CABLE":
                return CableGroup.POWER_CABLE;
            default:
                return null;
        }
    }
}
