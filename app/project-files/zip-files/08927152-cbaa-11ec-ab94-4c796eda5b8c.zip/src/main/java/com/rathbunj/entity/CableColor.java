package com.rathbunj.entity;

import org.springframework.data.annotation.Id;

import java.awt.Color;

public class CableColor {
    @Id
    private final Integer ID;
    private final String COLOR_NAME;
    private final Color COLOR_OBJ;

    public CableColor(Integer ID, String colorName, int redChannel,
                      int greenChannel, int blueChannel) {
        if (colorName == null || colorName.equals("") ||
                (redChannel < 0 || redChannel > 255) ||
                (greenChannel < 0 || greenChannel > 255) ||
                (blueChannel < 0 || blueChannel > 255)) {
            throw new IllegalArgumentException("Invalid argument in " +
                    "CableColor constructor.");
        }

        this.ID = ID;
        this.COLOR_NAME = colorName;
        this.COLOR_OBJ = new Color(redChannel, greenChannel, blueChannel);
    }

    public CableColor(int ID, String colorName, int rgbVal) {
        if (colorName == null || colorName.equals("") ||
                (rgbVal < 0 || rgbVal > 255)) {
            throw new IllegalArgumentException("Invalid argument in " +
                    "CableColor constructor.");
        }

        this.ID = ID;
        this.COLOR_NAME = colorName;
        this.COLOR_OBJ = new Color(rgbVal);
    }

    public int getID() {
        return ID;
    }

    public String getColorName() {
        return COLOR_NAME;
    }

    public int getRedChannel() {
        assert (COLOR_OBJ != null);

        if (COLOR_OBJ == null) {
            throw new NullPointerException("Color object is null.");
        } else {
            return COLOR_OBJ.getRed();
        }
    }

    public int getGreenChannel() {
        assert (COLOR_OBJ != null);

        if (COLOR_OBJ == null) {
            throw new NullPointerException("Color object is null.");
        } else {
            return COLOR_OBJ.getGreen();
        }
    }

    public int getBlueChannel() {
        assert (COLOR_OBJ != null);

        if (COLOR_OBJ == null) {
            throw new NullPointerException("Color object is null.");
        } else {
            return COLOR_OBJ.getBlue();
        }
    }
}