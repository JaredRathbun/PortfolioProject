package com.rathbunj.entity;

import org.springframework.data.annotation.Id;

public class Connector {
    @Id
    private int ID;
    private String connectorName;

    public Connector(int ID, String connectorName) {
        this.ID = ID;
        this.connectorName = connectorName;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getConnectorName() {
        return connectorName;
    }
}
