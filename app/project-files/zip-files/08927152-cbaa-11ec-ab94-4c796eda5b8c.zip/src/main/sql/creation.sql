DROP DATABASE IF EXISTS CableManager;
CREATE DATABASE CableManager;

USE CableManager;

/* Create the table for types of cables. */ 
DROP TABLE IF EXISTS CableTypes;
CREATE TABLE CableTypes (
	ID INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    TypeName VARCHAR(255) NOT NULL
);

/* Create a table for the locations. */ 
DROP TABLE IF EXISTS Locations;
CREATE TABLE Locations (
	ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    LocationName VARCHAR(255) NOT NULL
);

/* Create a table to map colors to each cable. */ 
DROP TABLE IF EXISTS Color;
CREATE TABLE Color (
	ID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    ColorName VARCHAR(100) NOT NULL UNIQUE,
    RedChannel INT,
    GreenChannel INT,
    BlueChannel INT,
    CONSTRAINT CHK_RED_CHANNEL CHECK (RedChannel > -1 AND RedChannel < 256),
    CONSTRAINT CHK_GREEN_CHANNEL CHECK (GreenChannel > -1 AND GreenChannel < 256),
    CONSTRAINT CHK_BLUE_CHANNEL CHECK (BlueChannel > -1 AND BlueChannel < 256)
);

/* A table to represent a connector. */
DROP TABLE IF EXISTS Connector;
CREATE TABLE Connector(
	ID INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    ConnectorName VARCHAR(255) NOT NULL
);

/* Create a table for cables. */ 
DROP TABLE IF EXISTS Cable;
CREATE TABLE Cable (
	ID INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    CableDescription TEXT NOT NULL,
    CableType INT NOT NULL,
    Length DOUBLE NOT NULL,
    DateAdded TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    LocationID INT NOT NULL,
    CableGroup VARCHAR(255) NOT NULL,
    FOREIGN KEY (LocationID) REFERENCES Locations(ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (CableType) REFERENCES CableTypes(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

/* Create a table to map cables and colors. */
DROP TABLE IF EXISTS CableColorMapper;
CREATE TABLE CableColorMapper(
	CableID INT NOT NULL,
    ColorID INT NOT NULL,
    FOREIGN KEY (CableID) REFERENCES Cable(ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (ColorID) REFERENCES Color(ID) ON DELETE CASCADE ON UPDATE CASCADE
);

/* Create a table to map cables and connectors. */
DROP TABLE IF EXISTS CableConnectorMapper;
CREATE TABLE CableConnectorMapper(
	CableID INT NOT NULL,
    ConnectorID INT NOT NULL,
    FOREIGN KEY (CableID) REFERENCES Cable(ID) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (ConnectorID) REFERENCES Connector(ID) ON DELETE CASCADE ON UPDATE CASCADE
);