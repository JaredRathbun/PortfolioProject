USE CableManager;

/* Inserts test data. */
DROP PROCEDURE IF EXISTS insertSampleData;
DELIMITER $$
CREATE PROCEDURE insertSampleData()
BEGIN
	INSERT INTO CableTypes (TypeName) VALUES ('HDMI Cable');
    INSERT INTO CableTypes (TypeName) VALUES ('Ethernet Cable');
    INSERT INTO CableTypes (TypeName) VALUES ('Audio Cable');
    INSERT INTO CableTypes (TypeName) VALUES ('USB-C Cable');
    
    INSERT INTO Connector (ConnectorName) VALUES ('HDMI Connector');
	INSERT INTO Connector (ConnectorName) VALUES ('Ethernet Connector');
	INSERT INTO Connector (ConnectorName) VALUES ('DisplayPort Connector');
    INSERT INTO Connector (ConnectorName) VALUES ('USB-C Connector');
    INSERT INTO Connector (ConnectorName) VALUES ('3.5mm Audio Connector');
    
	INSERT INTO Color (ColorName, RedChannel, GreenChannel, BlueChannel) VALUES ('Red', 255, 0, 0);
	INSERT INTO Color (ColorName, RedChannel, GreenChannel, BlueChannel) VALUES ('Black', 0, 0, 0);
    INSERT INTO Color (ColorName, RedChannel, GreenChannel, BlueChannel) VALUES ('Gray', 139, 147, 148);
    INSERT INTO Color (ColorName, RedChannel, GreenChannel, BlueChannel) VALUES ('White', 255, 255, 255);
    
	INSERT INTO Locations (LocationName) VALUES ('Cable Cabinet - Drawer 1');
	INSERT INTO Locations (LocationName) VALUES ('Cable Cabinet - Drawer 2');

    INSERT INTO Cable (CableDescription, CableType, Length, LocationID, CableGroup) VALUES ('HDMI Cable', 1, 2.54, 1, "DISPLAY_CABLE");
	INSERT INTO Cable (CableDescription, CableType, Length, LocationID, CableGroup) VALUES ('Ethernet Cable', 2, 6.0, 2, "DATA_CABLE");
    INSERT INTO Cable (CableDescription, CableType, Length, LocationID, CableGroup) VALUES ('3.5mm Audio Cable', 3, 6.0, 1, "AUDIO_CABLE");
    INSERT INTO Cable (CableDescription, CableType, Length, LocationID, CableGroup) VALUES ('USB-C Cable', 4, 3.0, 2, "DATA_CABLE");

    INSERT INTO CableColorMapper (CableID, ColorID) VALUES (1, 1);
	INSERT INTO CableColorMapper (CableID, ColorID) VALUES (1, 2);
	INSERT INTO CableColorMapper (CableID, ColorID) VALUES (2, 1);
    INSERT INTO CableColorMapper (CableID, ColorID) VALUES (3, 4);
	INSERT INTO CableColorMapper (CableID, ColorID) VALUES (4, 3);
	
	INSERT INTO CableConnectorMapper (CableID, ConnectorID) VALUES (1, 1);
	INSERT INTO CableConnectorMapper (CableID, ConnectorID) VALUES (1, 3);
	INSERT INTO CableConnectorMapper (CableID, ConnectorID) VALUES (2, 3);
	INSERT INTO CableConnectorMapper (CableID, ConnectorID) VALUES (2, 3);
    INSERT INTO CableConnectorMapper (CableID, ConnectorID) VALUES (3, 5);
    INSERT INTO CableConnectorMapper (CableID, ConnectorID) VALUES (3, 5);
	INSERT INTO CableConnectorMapper (CableID, ConnectorID) VALUES (4, 4);
    INSERT INTO CableConnectorMapper (CableID, ConnectorID) VALUES (4, 4);
END $$
DELIMITER ;

/* Gets all connectors that are associated with a specific cable. */
DROP PROCEDURE IF EXISTS getAllConnectorsByID;
DELIMITER $$
CREATE PROCEDURE getAllConnectorsByID(IN cableID INT)
BEGIN
	SELECT ID, ConnectorName
	FROM CableConnectorMapper as CCM 
	JOIN Connector as C ON CCM.ConnectorID = C.ID
    WHERE CCM.CableID = cableID;
END $$
DELIMITER ;

/* Gets all colors that are associated with a specific cable. */
DROP PROCEDURE IF EXISTS getAllColorsByID;
DELIMITER $$
CREATE PROCEDURE getAllColorsByID(IN cableID INT)
BEGIN
	SELECT ID, ColorName, RedChannel, BlueChannel, GreenChannel
	FROM CableColorMapper as CCM 
	JOIN Color as C ON CCM.ColorID = C.ID
    WHERE CCM.CableID = cableID;
END $$
DELIMITER ;
    
/* Creates a new cable. */ 
DROP PROCEDURE IF EXISTS addCable;
DELIMITER $$
CREATE PROCEDURE addCable(IN newCableDescription TEXT, IN newCableTypeID INT, IN newLength DOUBLE, IN newLocationID INT, IN newCableGroup VARCHAR(255))
BEGIN
	INSERT INTO Cable (CableDescription, CableType, Length, LocationID, CableGroup) 
    VALUES (newCableDescription, newCableTypeID, newLength, newLocationID, newCableGroup);
	
    SELECT LAST_INSERT_ID() AS "ID"; 
END $$
DELIMITER ; 

/* Inserts a new CableType. */
DROP PROCEDURE IF EXISTS addCableType;
DELIMITER $$
CREATE PROCEDURE addCableType(IN TypeName VARCHAR(255), OUT ID INT)
BEGIN
	INSERT INTO CableTypes (TypeName) VALUES (TypeName);

	/* Get the ID of inserted CableType and return it. */
	SET ID = LAST_INSERT_ID(); 
END $$
DELIMITER ;

/* Inserts a new Connector. */
DROP PROCEDURE IF EXISTS addConnector;
DELIMITER $$
CREATE PROCEDURE addConnector(IN connectorName VARCHAR(255), OUT ID INT)
BEGIN 
	INSERT INTO Connector (ConnectorName) VALUES (connectorName);
    SET ID = LAST_INSERT_ID();
END $$
DELIMITER ;

/* Inserts a new Color. */
DROP PROCEDURE IF EXISTS addColor;
DELIMITER $$
CREATE PROCEDURE addColor(IN colorName VARCHAR(255), IN redChannel INT, IN greenChannel INT, IN blueChannel INT)
BEGIN 
	INSERT INTO Color (ColorName, RedChannel, GreenChannel, BlueChannel)
    VALUES (colorName, redChannel, greenChannel, blueChannel);
    
    SELECT LAST_INSERT_ID() AS "ID";
END $$
DELIMITER ;

/* Inserts a new Location. */
DROP PROCEDURE IF EXISTS addLocation;
DELIMITER $$
CREATE PROCEDURE addLocation(IN locationName VARCHAR(255), OUT ID INT) 
BEGIN
	INSERT INTO Locations (LocationName) VALUES (locationName);

	SET ID = LAST_INSERT_ID();
END $$
DELIMITER ;

/* Inserts a new tuple into the CableColorMapper table. */
DROP PROCEDURE IF EXISTS addCableColorMappingEntry;
DELIMITER $$
CREATE PROCEDURE addCableColorMappingEntry(IN cableID INT, IN colorID INT)
BEGIN 
	INSERT INTO CableColorMapper (CableID, ColorID) VALUES (cableID, colorID);
END $$
DELIMITER ;

/* Inserts a new tuple into the CableConnectorMapper. */
DROP PROCEDURE IF EXISTS addCableConnectorMappingEntry;
DELIMITER $$
CREATE PROCEDURE addCableConnectorMappingEntry(IN cableID INT, IN connectorID INT)
BEGIN 
	INSERT INTO CableConnectorMapper (CableID, ConnectorID) VALUES (cableID, connectorID);
END $$
DELIMITER ;

/* Removes a CableConnectorMapper entry. */
DROP PROCEDURE IF EXISTS removeCableConnectorMappingEntry;
DELIMITER $$
CREATE PROCEDURE removeCableConnectorMappingEntry(IN deleteCableID INT, IN deleteConnectorID INT, OUT rowsEffected INT)
BEGIN 
	DELETE FROM CableConnectorMapper WHERE (CableID = deleteCableID AND ConnectorID = deleteConnectorID);
    SET rowsEffected = ROW_COUNT();
END $$
DELIMITER ;

/* Removes a CableColorMapper entry. */
DROP PROCEDURE IF EXISTS removeCableColorMappingEntry;
DELIMITER $$
CREATE PROCEDURE removeCableColorMappingEntry(IN deleteCableID INT, IN deleteColorID INT, OUT rowsEffected INT)
BEGIN 
	DELETE FROM CableColorMapper WHERE (CableID = deleteCableID AND ColorID = deleteColorID);
    SET rowsEffected = ROW_COUNT();
END $$
DELIMITER ;

/* Removes a cable. */
DROP PROCEDURE IF EXISTS removeCable;
DELIMITER $$
CREATE PROCEDURE removeCable(IN cableID INT, OUT rowsEffected INT)
BEGIN
	DELETE FROM Cable WHERE ID = cableID;
    SET rowsEffected = ROW_COUNT();
END $$
DELIMITER ;

/* Removes a connector. */
DROP PROCEDURE IF EXISTS removeConnector;
DELIMITER $$
CREATE PROCEDURE removeConnector(IN connectorID INT, OUT rowsEffected INT)
BEGIN
	DELETE FROM Connector WHERE ID = connectorID;
    SET rowsEffected = ROW_COUNT();
END $$
DELIMITER ;

/* Removes a color. */
DROP PROCEDURE IF EXISTS removeColor;
DELIMITER $$
CREATE PROCEDURE removeColor(IN colorID INT, OUT rowsEffected INT)
BEGIN
	DELETE FROM Color WHERE ID = colorID;
    SET rowsEffected = ROW_COUNT();
END $$
DELIMITER ;

/* Removes a location. */
DROP PROCEDURE IF EXISTS removeLocation;
DELIMITER $$
CREATE PROCEDURE removeLocation(IN locationID INT, OUT rowsEffected INT)
BEGIN
	DELETE FROM Location WHERE ID = locationID;
    SET rowsEffected = ROW_COUNT();
END $$
DELIMITER ;

/* Returns a boolean representing whether or not the location name is in the database already. */
DROP PROCEDURE IF EXISTS locationExists;
DELIMITER $$
CREATE PROCEDURE locationExists(IN searchLocationName VARCHAR(255))
BEGIN
	SELECT EXISTS (SELECT LocationName FROM Locations WHERE LocationName = searchLocationName) AS "result";
END $$
DELIMITER ;

/* Returns a boolean representing whether or not the CableType name is in the database already. */
DROP PROCEDURE IF EXISTS cableTypeExists;
DELIMITER $$
CREATE PROCEDURE cableTypeExists(IN searchCableType VARCHAR(255))
BEGIN
	SELECT EXISTS (SELECT TypeName FROM CableTypes WHERE TypeName = searchCableType) AS "result";
END $$
DELIMITER ;

/* Returns a boolean representing whether or not the ColorName is in the database already. */
DROP PROCEDURE IF EXISTS colorExists;
DELIMITER $$
CREATE PROCEDURE colorExists(IN searchColorName VARCHAR(100))
BEGIN 
	SELECT EXISTS (SELECT ColorName FROM Color WHERE ColorName = searchColorName) AS "result";
END $$
DELIMITER ;

/* Returns a boolean representing whether or not the ConnectorName is in the database already. */
DROP PROCEDURE IF EXISTS connectorExists;
DELIMITER $$
CREATE PROCEDURE connectorExists(IN searchConnectorName VARCHAR(255))
BEGIN
	SELECT EXISTS (SELECT ConnectorName FROM Connector WHERE ConnectorName = searchConnectorName) AS "result";
END $$
DELIMITER ;

/* Selects the @rowsEffected session variable. */
DROP PROCEDURE IF EXISTS getRowsEffected;
DELIMITER $$
CREATE PROCEDURE getRowsEffected()
BEGIN
	SELECT @rowsEffected AS "rowsEffected";
END $$
DELIMITER ;

/* Selects the @ID session variable. */
DROP PROCEDURE IF EXISTS getID;
DELIMITER $$
CREATE PROCEDURE getID()
BEGIN 
	SELECT @ID AS "ID";
END $$
DELIMITER ;

/* Selects all cables from the Cable table. */
DROP PROCEDURE IF EXISTS getAllCables;
DELIMITER $$
CREATE PROCEDURE getAllCables()
BEGIN
	SELECT ID, CableDescription, CableType, Length, DateAdded, LocationID, CableGroup 
    FROM Cable 
    ORDER BY ID;
END $$
DELIMITER ;

/* Selects a specific cable by ID. */
DROP PROCEDURE IF EXISTS getCableByID;
DELIMITER $$
CREATE PROCEDURE getCableByID(IN cableID INT)
BEGIN
	SELECT ID, CableDescription, CableType, Length, DateAdded, LocationID, CableGroup 
    FROM Cable 
    WHERE ID = cableID
    ORDER BY ID;
END $$
DELIMITER ;

/* Gets all colors in the Color table. */
DROP PROCEDURE IF EXISTS getAllColors;
DELIMITER $$
CREATE PROCEDURE getAllColors()
BEGIN
	SELECT ID, RedChannel, GreenChannel, BlueChannel 
    FROM Color 
    ORDER BY ID;
END $$
DELIMITER ;

/* Gets a color with the specific ColorName. */
DROP PROCEDURE IF EXISTS getColorByName;
DELIMITER $$
CREATE PROCEDURE getColorByName(IN searchColorName VARCHAR(255))
BEGIN
	SELECT ID, ColorName, RedChannel, GreenChannel, BlueChannel 
    FROM Color 
    WHERE ID = searchColorName
    ORDER BY ID; 
END $$
DELIMITER ;

/* Gets a CableType by ID. */
DROP PROCEDURE IF EXISTS getCableTypeByID;
DELIMITER $$
CREATE PROCEDURE getCableTypeByID(IN searchID VARCHAR(255))
BEGIN
	SELECT ID, TypeName
    FROM CableTypes 
    WHERE ID = searchID
    ORDER BY ID; 
END $$
DELIMITER ;

/* Gets a CableType by TypeName. */
DROP PROCEDURE IF EXISTS getCableTypeByTypeName;
DELIMITER $$
CREATE PROCEDURE getCableTypeByTypeName(IN searchTypeName VARCHAR(255))
BEGIN
	SELECT ID, TypeName
    FROM CableTypes 
    WHERE TypeName = searchTypeName
    ORDER BY ID; 
END $$
DELIMITER ;

/* Gets all CableTypes in the CableTypes table. */
DROP PROCEDURE IF EXISTS getAllCableTypes;
DELIMITER $$
CREATE PROCEDURE getAllCableTypes()
BEGIN
	SELECT ID, TypeName
    FROM CableTypes
    ORDER BY ID; 
END $$
DELIMITER ;

/* Gets a Connector by ID. */
DROP PROCEDURE IF EXISTS getConnectorByID;
DELIMITER $$
CREATE PROCEDURE getConnectorByID(IN searchID VARCHAR(255))
BEGIN
	SELECT ID, ConnectorName
    FROM Connector 
    WHERE ID = searchID
    ORDER BY ID; 
END $$
DELIMITER ;

/* Gets a Connector by a ConnectorName. */
DROP PROCEDURE IF EXISTS getConnectorByName;
DELIMITER $$
CREATE PROCEDURE getConnectorByName(IN searchName VARCHAR(255))
BEGIN
	SELECT ID, ConnectorName
    FROM Connector 
    WHERE ID = searchName
    ORDER BY ID; 
END $$
DELIMITER ;

/* Gets all CableTypes in the CableTypes table. */
DROP PROCEDURE IF EXISTS getAllConnectors;
DELIMITER $$
CREATE PROCEDURE getAllConnectors()
BEGIN
	SELECT ID, ConnectorName
    FROM Connector
    ORDER BY ID; 
END $$
DELIMITER ;

/* Gets a Location by ID. */
DROP PROCEDURE IF EXISTS getLocationByID;
DELIMITER $$
CREATE PROCEDURE getLocationByID(IN searchID VARCHAR(255))
BEGIN
	SELECT ID, LocationName
    FROM Locations 
    WHERE ID = searchID
    ORDER BY ID; 
END $$
DELIMITER ;

/* Gets a Location by name. */
DROP PROCEDURE IF EXISTS getLocationByName;
DELIMITER $$
CREATE PROCEDURE getLocationByName(IN searchName VARCHAR(255))
BEGIN
	SELECT ID, LocationName
    FROM Locations
    WHERE ID = searchName
    ORDER BY ID; 
END $$
DELIMITER ;

/* Gets all locations in the locations table. */
DROP PROCEDURE IF EXISTS getAllLocations;
DELIMITER $$
CREATE PROCEDURE getAllLocations()
BEGIN
	SELECT ID, LocationName
    FROM Locations
    ORDER BY ID; 
END $$
DELIMITER ;


