USE CableManager;

-- Insert the starting and sample data.
CALL insertSampleData(); 

-- There should be 4 cables in the database. 1 HDMI, 1 Ethernet, 1 3.5mm, and 1 USB-C Cable. 
SELECT * FROM Cable;

-- There should be 4 entries in the color table. 
SELECT * FROM Color;

-- There should be 5 connectors 
SELECT * FROM Connector;

-- There should be 5 entries in the CableColorMapper, 2 for ID 1 and 1 for IDs 2, 3 and 4. 
SELECT * FROM CableColorMapper; 

-- There should be 8 entries in the CableConnectorMapper, 2 foe every ID. 
SELECT * FROM CableConnectorMapper;

-- Get the colors for cable 1. There should be 2 rows, one for Red and the other for Black.
CALL getAllColorsById(1);

-- Get all of the connectors for cable 1. There should be one HDMI connector and one DisplayPort connector.
CALL getAllConnectorsById(1); 

-- Add a new cable, connector, and map them together along with the color black.
CALL addConnector('DVI-D Connector', @ID);
SET @newConnectorID = @ID;

CALL addCableType('DVI Cable', @ID);
SET @newCableTypeID = @ID;

CALL addLocation('On the ceiling', @ID);
SET @newLocationID = @ID;
CALL addCable('DVI-D Cable', @newCableTypeID, 3.33, @newLocationID, 'DISPLAY_CABLE');
SET @newCableID = @ID;

CALL addCableColorMappingEntry(@newCableID, 2);
CALL addCableConnectorMappingEntry(@newCableID, @newConnectorID);
CALL addCableConnectorMappingEntry(@newCableID, @newConnectorID);

-- There should now be 5 cables in the database.
SELECT COUNT(*) FROM Cable;

-- There should be 10 rows in the CableConnectorMapper. 
SELECT COUNT(*) FROM CableConnectorMapper;

-- There should be 6 rows in the CableColorMapper. 
SELECT COUNT(*) FROM CableColorMapper;

-- There should be 1 row changed, and 5 rows in the CableColorMapper. 
CALL removeColor(@newCableID, @rowsEffected);
SELECT @rowsEffected AS 'Rows Effected', COUNT(*) AS 'Num of CableColorMappings' FROM CableColorMapper;

-- There should be a Color with the name 'Black' and a connector with the name 'HDMI Connector'.
CALL colorExists('Black');
CALL connectorExists('HDMI Connector');